package com.juyel.totka.home

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.juyel.totka.data.CsvParser
import com.juyel.totka.data.GasApi
import com.juyel.totka.data.models.MasterEntry
import com.juyel.totka.databinding.ActivityHomeBinding
import com.juyel.totka.profile.ProfileActivity
import com.juyel.totka.quiz.QuizActivity
import com.juyel.totka.utils.Constants
import com.juyel.totka.utils.UserPrefs
import kotlinx.coroutines.launch
import org.json.JSONArray

class HomeActivity : AppCompatActivity() {

    private lateinit var b: ActivityHomeBinding
    private lateinit var prefs: UserPrefs

    private var masterData: List<MasterEntry> = emptyList()
    private var selectedEntry: MasterEntry?   = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b     = ActivityHomeBinding.inflate(layoutInflater)
        prefs = UserPrefs(this)
        setContentView(b.root)

        setupUserHeader()
        loadMaster()

        b.btnStartQuiz.setOnClickListener { startQuiz() }
        b.btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }

    override fun onResume() { super.onResume(); setupUserHeader() }

    // ── Header ────────────────────────────────────────────────
    private fun setupUserHeader() {
        val user = prefs.getUser() ?: return
        b.txtWelcome.text  = "হ্যালো, ${user.fullName.split(" ").first()} 👋"
        b.txtStreak.text   = "🔥 ${prefs.streak} day streak"
        prefs.profilePicPath?.let {
            Glide.with(this).load(it).circleCrop().into(b.imgAvatar)
        }
    }

    // ── Load Master ───────────────────────────────────────────
    private fun loadMaster() {
        b.progressMaster.visibility = View.VISIBLE
        b.cardFilters.visibility    = View.GONE

        lifecycleScope.launch {
            val csv = if (prefs.isMasterCacheValid) {
                prefs.masterCache!!
            } else {
                val r = GasApi.fetchCsv(Constants.MASTER_CSV_URL)
                r.getOrNull()?.also {
                    prefs.masterCache    = it
                    prefs.masterTimestamp = System.currentTimeMillis()
                } ?: run {
                    showError("Master sheet load হয়নি"); return@launch
                }
            }

            masterData = CsvParser.parseMaster(csv)
            b.progressMaster.visibility = View.GONE
            b.cardFilters.visibility    = View.VISIBLE

            // Pre-fill user's board & class
            val user = prefs.getUser()
            setupBoardSpinner(user?.board, user?.classVal)
        }
    }

    // ── Spinner chain: Board → Class → Subject → Chapter ─────
    private fun setupBoardSpinner(defaultBoard: String? = null, defaultClass: String? = null) {
        val boards = masterData.map { it.board }.distinct().filter { it.isNotBlank() }
        b.spinnerBoard.adapter = makeAdapter(listOf("— Board —") + boards)

        b.spinnerBoard.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val board = if (pos == 0) "" else boards[pos - 1]
                setupClassSpinner(board, defaultClass)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Auto-select user's board
        defaultBoard?.let { board ->
            val idx = boards.indexOfFirst { it.equals(board, ignoreCase = true) }
            if (idx >= 0) b.spinnerBoard.setSelection(idx + 1)
        }
    }

    private fun setupClassSpinner(board: String, defaultClass: String? = null) {
        val classes = masterData.filter { board.isEmpty() || it.board == board }
            .map { it.classVal }.distinct().filter { it.isNotBlank() }
        b.spinnerClass.adapter = makeAdapter(listOf("— Class —") + classes)

        b.spinnerClass.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val cls = if (pos == 0) "" else classes[pos - 1]
                setupSubjectSpinner(board, cls)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        defaultClass?.let { cls ->
            val idx = classes.indexOfFirst { it.equals(cls, ignoreCase = true) }
            if (idx >= 0) b.spinnerClass.setSelection(idx + 1)
        }
    }

    private fun setupSubjectSpinner(board: String, cls: String) {
        val subjects = masterData
            .filter { (board.isEmpty() || it.board == board) && (cls.isEmpty() || it.classVal == cls) }
            .map { it.subject }.distinct().filter { it.isNotBlank() }
        b.spinnerSubject.adapter = makeAdapter(listOf("— Subject —") + subjects)

        b.spinnerSubject.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val subj = if (pos == 0) "" else subjects[pos - 1]
                setupChapterSpinner(board, cls, subj)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun setupChapterSpinner(board: String, cls: String, subject: String) {
        val entries = masterData.filter {
            (board.isEmpty()   || it.board    == board) &&
            (cls.isEmpty()     || it.classVal == cls)   &&
            (subject.isEmpty() || it.subject  == subject)
        }
        val chapters = entries.map { it.chapter }.filter { it.isNotBlank() }
        b.spinnerChapter.adapter = makeAdapter(listOf("— Chapter —") + chapters)

        b.spinnerChapter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedEntry = if (pos == 0) null else entries.getOrNull(pos - 1)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    // ── Start Quiz ────────────────────────────────────────────
    private fun startQuiz() {
        val entry = selectedEntry ?: run { snack("Chapter সিলেক্ট করুন"); return }
        val diff   = when (b.spinnerDifficulty.selectedItemPosition) {
            1 -> "easy"; 2 -> "medium"; 3 -> "hard"; else -> "all"
        }
        val qCount = b.etQCount.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 10
        val mode   = if (b.rbMcq.isChecked) "mcq" else "flashcard"

        startActivity(Intent(this, QuizActivity::class.java).apply {
            putExtra(Constants.EXTRA_CSV_LINK,   entry.csvLink)
            putExtra(Constants.EXTRA_BOARD,      entry.board)
            putExtra(Constants.EXTRA_CLASS,      entry.classVal)
            putExtra(Constants.EXTRA_SUBJECT,    entry.subject)
            putExtra(Constants.EXTRA_CHAPTER,    entry.chapter)
            putExtra(Constants.EXTRA_DIFFICULTY, diff)
            putExtra(Constants.EXTRA_Q_COUNT,    qCount)
            putExtra(Constants.EXTRA_MODE,       mode)
        })
    }

    private fun makeAdapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

    private fun showError(msg: String) {
        b.progressMaster.visibility = View.GONE
        snack(msg)
    }

    private fun snack(msg: String) =
        Snackbar.make(b.root, msg, Snackbar.LENGTH_LONG).show()
}
