package com.juyel.totka.quiz

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.juyel.totka.data.CsvParser
import com.juyel.totka.data.GasApi
import com.juyel.totka.data.models.Question
import com.juyel.totka.databinding.ActivityQuizBinding
import com.juyel.totka.result.ResultActivity
import com.juyel.totka.utils.Constants
import kotlinx.coroutines.launch

class QuizActivity : AppCompatActivity() {

    private lateinit var b: ActivityQuizBinding
    private var questions: List<Question> = emptyList()
    private var answers:   Array<String>  = emptyArray()   // "A"|"B"|"C"|"D"|""
    private var current   = 0
    private var answered  = false
    private var timer: CountDownTimer? = null
    private var timePerQ  = 30   // seconds per question

    // Intent extras
    private var csvLink   = ""
    private var difficulty = "all"
    private var qCount    = 10
    private var mode      = "mcq"

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(b.root)

        csvLink    = intent.getStringExtra(Constants.EXTRA_CSV_LINK)   ?: ""
        difficulty = intent.getStringExtra(Constants.EXTRA_DIFFICULTY) ?: "all"
        qCount     = intent.getIntExtra(Constants.EXTRA_Q_COUNT, 10)
        mode       = intent.getStringExtra(Constants.EXTRA_MODE)       ?: "mcq"

        b.txtMeta.text = "${intent.getStringExtra(Constants.EXTRA_SUBJECT)} · " +
                         intent.getStringExtra(Constants.EXTRA_CHAPTER)

        setupOptionButtons()
        loadQuestions()
    }

    private fun loadQuestions() {
        setLoading(true)
        lifecycleScope.launch {
            val result = GasApi.fetchCsv(csvLink)
            setLoading(false)
            result.fold(
                onSuccess = { csv ->
                    var pool = CsvParser.parseQuestions(csv)
                    if (difficulty != "all") pool = pool.filter { it.difficulty == difficulty }
                    if (pool.isEmpty()) { snack("প্রশ্ন পাওয়া যায়নি"); finish(); return@launch }
                    pool = pool.shuffled().take(qCount)
                    questions = pool
                    answers   = Array(questions.size) { "" }
                    showQuestion(0)
                },
                onFailure = { e -> snack(e.message ?: "Load failed"); finish() }
            )
        }
    }

    // ── Render Question ───────────────────────────────────────
    private fun showQuestion(idx: Int) {
        current  = idx
        answered = answers[idx].isNotEmpty()
        val q    = questions[idx]

        b.progressBar.max      = questions.size
        b.progressBar.progress = idx + 1
        b.txtProgress.text     = "${idx + 1} / ${questions.size}"
        b.txtQuestion.text     = q.question

        val opts  = q.options()
        val btns  = listOf(b.btnA, b.btnB, b.btnC, b.btnD)
        val labels= listOf("A", "B", "C", "D")
        btns.forEachIndexed { i, btn ->
            btn.text = "${labels[i]}.  ${opts[i]}"
            resetBtnStyle(btn)
        }

        if (answered) {
            highlightAnswers(q)
        } else {
            timer?.cancel()
            if (mode == "mcq") startTimer()
        }

        b.btnPrev.isEnabled    = idx > 0
        b.btnNext.visibility   = if (idx < questions.size - 1) View.VISIBLE else View.GONE
        b.btnSubmit.visibility = if (idx == questions.size - 1) View.VISIBLE else View.GONE
        b.cardExplanation.visibility = if (answered && q.explanation.isNotBlank()) View.VISIBLE else View.GONE
        b.txtExplanation.text  = q.explanation
    }

    private fun setupOptionButtons() {
        listOf(b.btnA to "A", b.btnB to "B", b.btnC to "C", b.btnD to "D").forEach { (btn, letter) ->
            btn.setOnClickListener { onAnswer(letter) }
        }
        b.btnPrev.setOnClickListener   { showQuestion(current - 1) }
        b.btnNext.setOnClickListener   { showQuestion(current + 1) }
        b.btnSubmit.setOnClickListener { submitQuiz() }
    }

    private fun onAnswer(letter: String) {
        if (answered) return
        answered = true
        answers[current] = letter
        timer?.cancel()
        highlightAnswers(questions[current])
        b.cardExplanation.visibility = if (questions[current].explanation.isNotBlank()) View.VISIBLE else View.GONE
        b.txtExplanation.text = questions[current].explanation
    }

    private fun highlightAnswers(q: Question) {
        val selected = answers[current]
        val btns     = mapOf("A" to b.btnA, "B" to b.btnB, "C" to b.btnC, "D" to b.btnD)
        btns.forEach { (letter, btn) ->
            when {
                letter == q.correct             -> btn.setBackgroundColor(Color.parseColor("#22C55E"))
                letter == selected && selected != q.correct -> btn.setBackgroundColor(Color.parseColor("#EF4444"))
                else                            -> resetBtnStyle(btn)
            }
        }
    }

    private fun resetBtnStyle(btn: android.widget.Button) {
        btn.setBackgroundColor(Color.parseColor("#1E1B3A"))
    }

    // ── Timer ─────────────────────────────────────────────────
    private fun startTimer() {
        b.txtTimer.visibility = View.VISIBLE
        timer = object : CountDownTimer(timePerQ * 1000L, 1000L) {
            override fun onTick(ms: Long) { b.txtTimer.text = "⏱ ${ms / 1000}s" }
            override fun onFinish() {
                b.txtTimer.text = "⏱ 0s"
                if (!answered) onAnswer("")   // auto-skip
            }
        }.start()
    }

    // ── Submit ────────────────────────────────────────────────
    private fun submitQuiz() {
        timer?.cancel()
        val intent = Intent(this, ResultActivity::class.java).apply {
            putParcelableArrayListExtra("questions", ArrayList(questions))
            putStringArrayListExtra("answers",       ArrayList(answers.toList()))
            putExtra("subject",  this@QuizActivity.intent.getStringExtra(Constants.EXTRA_SUBJECT))
            putExtra("chapter",  this@QuizActivity.intent.getStringExtra(Constants.EXTRA_CHAPTER))
        }
        startActivity(intent)
        finish()
    }

    private fun setLoading(b: Boolean) {
        this.b.progressLoading.visibility = if (b) View.VISIBLE else View.GONE
        this.b.quizContent.visibility     = if (b) View.GONE    else View.VISIBLE
    }

    private fun snack(msg: String) = Snackbar.make(b.root, msg, Snackbar.LENGTH_LONG).show()

    override fun onDestroy() { super.onDestroy(); timer?.cancel() }
}
