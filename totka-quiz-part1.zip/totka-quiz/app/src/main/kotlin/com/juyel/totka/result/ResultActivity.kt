package com.juyel.totka.result

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.juyel.totka.R
import com.juyel.totka.data.models.Question
import com.juyel.totka.databinding.ActivityResultBinding
import com.juyel.totka.home.HomeActivity
import com.juyel.totka.utils.UserPrefs
import nl.dionsegijn.konfetti.core.Party
import nl.dionsegijn.konfetti.core.Position
import nl.dionsegijn.konfetti.core.emitter.Emitter
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class ResultActivity : AppCompatActivity() {

    private lateinit var b: ActivityResultBinding
    private lateinit var prefs: UserPrefs

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b     = ActivityResultBinding.inflate(layoutInflater)
        prefs = UserPrefs(this)
        setContentView(b.root)

        val questions = intent.getParcelableArrayListExtra<Question>("questions") ?: return
        val answers   = intent.getStringArrayListExtra("answers") ?: return
        val subject   = intent.getStringExtra("subject") ?: ""
        val chapter   = intent.getStringExtra("chapter") ?: ""

        var correct = 0; var wrong = 0; var skipped = 0
        questions.forEachIndexed { i, q ->
            when {
                answers[i].isBlank()      -> skipped++
                answers[i] == q.correct   -> correct++
                else                      -> wrong++
            }
        }

        val total   = questions.size
        val pct     = if (total > 0) (correct * 100) / total else 0

        b.txtSubjectChapter.text = "$subject · $chapter"
        b.txtScore.text          = "$correct / $total"
        b.txtPercent.text        = "$pct%"
        b.txtCorrect.text        = correct.toString()
        b.txtWrong.text          = wrong.toString()
        b.txtSkipped.text        = skipped.toString()
        b.resultEmoji.text       = when {
            pct >= 90 -> "🏆"
            pct >= 70 -> "🎉"
            pct >= 50 -> "👍"
            else      -> "💪"
        }
        b.txtGrade.text = when {
            pct >= 90 -> "অসাধারণ! Excellent!"
            pct >= 70 -> "দারুণ! Well Done!"
            pct >= 50 -> "ভালো! Keep Going!"
            else      -> "আরো চেষ্টা করো! Try Again!"
        }

        // Update streak
        updateStreak()

        // Confetti + sound
        if (pct >= com.juyel.totka.utils.Constants.CONFETTI_THRESHOLD) {
            launchConfetti()
            playClapSound()
        }

        // Review list
        buildReview(questions, answers)

        b.btnNewQuiz.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finishAffinity()
        }
        b.btnRetryWrong.setOnClickListener { finish() }   // TODO: pass wrong Qs back
        b.btnShare.setOnClickListener      { shareResult(subject, chapter, pct, correct, total) }
    }

    private fun updateStreak() {
        val today  = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (prefs.lastQuizDay != today) {
            val yesterday = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(Date(System.currentTimeMillis() - 86_400_000))
            prefs.streak = if (prefs.lastQuizDay == yesterday) prefs.streak + 1 else 1
            prefs.lastQuizDay = today
        }
        b.txtStreak.text = "🔥 ${prefs.streak} day streak!"
    }

    private fun launchConfetti() {
        b.konfettiView.start(Party(
            emitter = Emitter(duration = 3, TimeUnit.SECONDS).perSecond(80),
            position = Position.Relative(0.5, 0.0)
        ))
    }

    private fun playClapSound() {
        try {
            MediaPlayer.create(this, R.raw.clap)?.apply {
                setOnCompletionListener { release() }
                start()
            }
        } catch (_: Exception) {}
    }

    private fun buildReview(questions: List<Question>, answers: List<String>) {
        val sb = StringBuilder()
        questions.forEachIndexed { i, q ->
            val icon = when {
                answers[i].isBlank()    -> "⚪"
                answers[i] == q.correct -> "✅"
                else                    -> "❌"
            }
            sb.appendLine("$icon Q${i + 1}. ${q.question}")
            if (answers[i].isNotBlank() && answers[i] != q.correct) {
                sb.appendLine("   তোমার উত্তর: ${answers[i]}  |  সঠিক: ${q.correct}")
            }
            sb.appendLine()
        }
        b.txtReview.text = sb.toString()
    }

    private fun shareResult(subject: String, chapter: String, pct: Int, correct: Int, total: Int) {
        val text = "📚 Quiz Master\n$subject · $chapter\n\n✅ Score: $correct/$total ($pct%)\n\n#QuizMaster #TotkaQuiz"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
        }, "Share Result"))
    }
}
